#!/bin/bash

#./searchClass.py --name="douglas Fir"
#./searchClass.py --name="evergreen"
#./searchClass.py --type="soil"
#./searchClass.py --type="stratum,soil"
./searchClass.py --type="all"
#./searchClass.py --location=Oregon
#./searchClass.py --species=rubra
#./searchClass.py --genus=Alnus
