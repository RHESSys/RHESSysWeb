#!/bin/bash

#insertParams.py -v --type="stratum" --name="Red Alder"   --parentName="deciduous" --user="Peter Slaughter" --genus="Alnus" --species="rubra" example/veg_redalder.def
#insertParams.py -v --type="stratum" --name="Red Alder"   --parentName="deciduous" --user="Peter Slaughter" --location="Oregon" --genus="Alnus" --species="rubra" example/veg_redalder_oregon.def

#insertParams.py -v --type="stratum" --name="Douglas Fir" --parentName="evergreen" --user="Peter Slaughter" example/veg_douglasfir.def 
#insertParams.py -v --type="stratum" --name="Douglas Fir" --parentName="evergreen" --location="Oregon" --user="Peter Slaughter" example/veg_douglasfir_oregon.def 
#insertParams.py -v --type="stratum" --name="Douglas Fir" --parentName="evergreen" --location="New Mexico" --user="Peter Slaughter" example/veg_douglasfir_newmexico.def     
