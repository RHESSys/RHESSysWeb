#!/bin/bash

#./deleteParams.py -v --searchType=hierarchical --class="Red Alder" --location="Oregon"
#./deleteParams.py -v --searchType=constrained --param="snow" --name="Red Alder" --location="Oregon"

./deleteParams.py -v --searchType=constrained --class="Sandy Loam" --startDatetime="2013 04 12"
