/*--------------------------------------------------------------*/
/* 																*/
/*					construct_netcdf_grid	 					*/
/*																*/
/*	construct_netcdf_grid.c - makes a base station object 		*/
/*																*/
/*	NAME														*/
/*	construct_netcdf_grid.c - makes base station object 		*/
/*																*/
/*	SYNOPSIS													*/
/*	construct_netcdf_grid( 										*/
/*							 base_station_file_name,			*/
/*							 start_date,						*/
/*							 duration							*/
/*							 column_index);						*/
/*																*/
/*	OPTIONS														*/
/*																*/
/*	DESCRIPTION													*/
/*																*/
/*--------------------------------------------------------------*/




