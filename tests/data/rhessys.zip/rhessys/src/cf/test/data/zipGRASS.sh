#!/bin/sh
zip -r GRASSData.zip GRASSData -x GRASSData/.DS_Store GRASSData/*/.DS_Store
