#!/bin/bash
# This shell script is an example of how to run the cxy program.

cxy -v xmap=xmap ymap=ymap
